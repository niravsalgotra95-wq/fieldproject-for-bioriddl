
import React from 'react';
import { Alert } from '../types';
import { AlertCircle, ArrowRight } from 'lucide-react';

interface AlertsPanelProps {
  alerts: Alert[];
}

const AlertsPanel: React.FC<AlertsPanelProps> = ({ alerts }) => {
  return (
    <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-bold text-slate-900">Risk Alerts</h2>
        <span className="text-xs font-semibold px-2 py-1 bg-slate-100 rounded-lg text-slate-500 uppercase">Live Now</span>
      </div>
      
      <div className="space-y-3">
        {alerts.map((alert) => (
          <div key={alert.id} className="p-4 rounded-xl border border-red-50 border-l-4 border-l-red-500 bg-red-50/30">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-bold text-sm text-slate-900">{alert.type} Risk</span>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                    alert.severity === 'High' ? 'bg-red-100 text-red-700' : 
                    alert.severity === 'Medium' ? 'bg-orange-100 text-orange-700' : 'bg-yellow-100 text-yellow-700'
                  }`}>
                    {alert.severity}
                  </span>
                </div>
                <p className="text-sm text-slate-600 mb-2">{alert.cause}</p>
                <div className="flex items-center text-xs font-semibold text-indigo-600 cursor-pointer hover:underline">
                  View Suggested Action: {alert.suggestion} <ArrowRight className="w-3 h-3 ml-1" />
                </div>
              </div>
            </div>
          </div>
        ))}
        {alerts.length === 0 && (
          <div className="py-8 text-center text-slate-400 text-sm italic">
            No active risks detected. Buddy is safe!
          </div>
        )}
      </div>
    </div>
  );
};

export default AlertsPanel;
