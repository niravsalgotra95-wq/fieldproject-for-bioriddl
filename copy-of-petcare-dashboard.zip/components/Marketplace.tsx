
import React, { useState } from 'react';
import { MarketplaceItem } from '../types';
import { getSearchGroundedTip } from '../services/geminiService';
import { ShoppingCart, Star, GraduationCap, Pill, Utensils, Gamepad2, Scissors, Watch, LayoutGrid, Search, X, Sparkles, Loader2, ExternalLink } from 'lucide-react';

interface MarketplaceProps {
  items: MarketplaceItem[];
}

const Marketplace: React.FC<MarketplaceProps> = ({ items }) => {
  const [filter, setFilter] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [cart, setCart] = useState<MarketplaceItem[]>([]);
  const [showCart, setShowCart] = useState(false);
  const [aiSearchQuery, setAiSearchQuery] = useState('');
  const [aiResponse, setAiResponse] = useState<{text: string, sources: any[]} | null>(null);
  const [isAiSearching, setIsAiSearching] = useState(false);

  const categories = [
    { id: 'All', icon: LayoutGrid },
    { id: 'Food', icon: Utensils },
    { id: 'Toys', icon: Gamepad2 },
    { id: 'Supplements', icon: Pill },
    { id: 'Training', icon: GraduationCap },
    { id: 'Wearables', icon: Watch },
    { id: 'Grooming', icon: Scissors }
  ];
  
  const filteredItems = items.filter(i => {
    const matchesFilter = filter === 'All' || i.category.toLowerCase() === filter.toLowerCase();
    const matchesSearch = i.name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const handleAiSearch = async () => {
    if (!aiSearchQuery.trim()) return;
    setIsAiSearching(true);
    const result = await getSearchGroundedTip(aiSearchQuery);
    setAiResponse(result);
    setIsAiSearching(false);
  };

  const addToCart = (item: MarketplaceItem) => {
    setCart([...cart, item]);
  };

  const removeFromCart = (id: string) => {
    setCart(cart.filter(i => i.id !== id));
  };

  const totalPrice = cart.reduce((acc, item) => acc + parseFloat(item.price.replace('$', '')), 0);

  return (
    <div className="bg-white dark:bg-slate-900 p-4 md:p-8 rounded-[2rem] md:rounded-[3rem] shadow-sm border border-slate-100 dark:border-slate-800 transition-colors duration-300">
      {/* AI Shopper - Powered by Grounded Search */}
      <div className="mb-10 p-6 bg-gradient-to-br from-indigo-50 to-orange-50 dark:from-indigo-950/20 dark:to-orange-950/10 rounded-[2.5rem] border border-indigo-100 dark:border-indigo-900/30">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-white dark:bg-slate-900 rounded-2xl shadow-sm text-indigo-600">
            <Sparkles className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-xl font-black text-slate-900 dark:text-white">Smart Shopper AI</h3>
            <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">Powered by Google Search</p>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-3 mb-6">
          <input 
            type="text" 
            placeholder="Ask AI: 'Best joint supplements for Labradors' or 'Local pet supply sales'..."
            className="flex-1 px-6 py-4 bg-white dark:bg-slate-900 rounded-2xl border border-transparent focus:border-indigo-500 outline-none dark:text-white text-sm"
            value={aiSearchQuery}
            onChange={(e) => setAiSearchQuery(e.target.value)}
          />
          <button 
            onClick={handleAiSearch}
            disabled={isAiSearching}
            className="px-8 py-4 bg-indigo-600 text-white rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-indigo-700 active:scale-95 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {isAiSearching ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Search Web'}
          </button>
        </div>

        {aiResponse && (
          <div className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm p-6 rounded-2xl border border-white dark:border-slate-800 animate-in fade-in slide-in-from-top-4">
            <p className="text-sm font-bold text-slate-800 dark:text-slate-200 leading-relaxed mb-4">
              {aiResponse.text}
            </p>
            {aiResponse.sources.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {aiResponse.sources.map((s: any, idx: number) => (
                  <a 
                    key={idx} 
                    href={s.web?.uri} 
                    target="_blank" 
                    className="flex items-center gap-2 px-3 py-1.5 bg-slate-50 dark:bg-slate-800 rounded-lg text-[10px] font-black text-indigo-600 hover:bg-indigo-50 transition-colors border border-indigo-50 dark:border-indigo-900/20"
                  >
                    <ExternalLink className="w-3 h-3" />
                    {s.web?.title || 'Source'}
                  </a>
                ))}
              </div>
            )}
            <button onClick={() => setAiResponse(null)} className="mt-4 text-[10px] font-black uppercase text-slate-400 hover:text-red-500">Clear AI Analysis</button>
          </div>
        )}
      </div>

      <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 md:mb-10 gap-6">
        <div>
          <h2 className="text-2xl md:text-3xl font-black text-slate-900 dark:text-white">Curated Finds</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 font-bold">Matched to your pet's behavior profile</p>
        </div>
        
        <div className="flex flex-col sm:flex-row items-center gap-3">
          <div className="relative w-full sm:w-auto">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search catalog..."
              className="w-full sm:w-48 pl-10 pr-4 py-3 text-sm bg-slate-50 dark:bg-slate-800 rounded-xl border border-transparent focus:border-orange-500 outline-none dark:text-white transition-all"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <button 
            onClick={() => setShowCart(true)}
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3 bg-orange-600 text-white rounded-xl font-black shadow-lg hover:bg-orange-700 relative"
          >
            <ShoppingCart className="w-4 h-4" />
            View Cart
            {cart.length > 0 && (
              <span className="absolute -top-2 -right-2 w-6 h-6 bg-slate-900 text-white text-[10px] flex items-center justify-center rounded-full border-2 border-white">{cart.length}</span>
            )}
          </button>
        </div>
      </div>

      <div className="flex overflow-x-auto pb-6 -mx-2 px-2 no-scrollbar gap-2 mb-8">
        {categories.map(cat => (
          <button
            key={cat.id}
            onClick={() => setFilter(cat.id)}
            className={`whitespace-nowrap px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all border flex items-center gap-2.5 ${
              filter === cat.id 
                ? 'bg-orange-600 text-white border-orange-600 shadow-xl' 
                : 'bg-white dark:bg-slate-800 text-slate-500 dark:text-slate-400 border-slate-100 dark:border-slate-700 hover:border-orange-400'
            }`}
          >
            <cat.icon className="w-4 h-4" />
            {cat.id}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 md:gap-8">
        {filteredItems.map((item) => (
          <div key={item.id} className="group flex flex-col h-full border border-slate-100 dark:border-slate-800 rounded-[2.5rem] p-5 hover:border-orange-200 dark:hover:border-orange-900/30 hover:shadow-2xl transition-all bg-white dark:bg-slate-900 relative overflow-hidden">
            <div className="absolute top-4 left-4 z-10">
              <span className="px-3 py-1 bg-white/90 dark:bg-slate-900/90 backdrop-blur-sm rounded-lg text-[8px] font-black uppercase tracking-widest border border-slate-100 dark:border-slate-800 text-orange-600">AI MATCH</span>
            </div>
            
            <div className="relative aspect-square mb-6 rounded-[2rem] overflow-hidden bg-slate-50 dark:bg-slate-800">
              <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
            </div>
            
            <div className="flex-1">
              <h3 className="text-lg font-black text-slate-800 dark:text-white mb-2">{item.name}</h3>
              <p className="p-4 bg-orange-50/50 dark:bg-orange-950/10 rounded-2xl text-[11px] text-orange-700 dark:text-orange-400 mb-6 font-bold italic leading-relaxed border border-orange-100 dark:border-orange-900/20">
                "{item.reason}"
              </p>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between px-1">
                <span className="text-2xl font-black text-slate-900 dark:text-white">{item.price}</span>
                <div className="flex items-center gap-1.5 px-3 py-1 bg-amber-50 dark:bg-amber-950/30 rounded-full text-amber-600 border border-amber-100 dark:border-amber-900/20">
                  <Star className="w-3.5 h-3.5 fill-current" />
                  <span className="text-xs font-black">4.8</span>
                </div>
              </div>
              <button 
                onClick={() => addToCart(item)}
                className="w-full py-4 bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-xs font-black uppercase tracking-[0.2em] rounded-2xl flex items-center justify-center gap-3 active:scale-95 transition-all hover:bg-orange-600 dark:hover:bg-orange-600 dark:hover:text-white"
              >
                <ShoppingCart className="w-4 h-4" /> Add to Order
              </button>
            </div>
          </div>
        ))}
      </div>

      {showCart && (
        <div className="fixed inset-0 z-[2000] flex justify-end">
          <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm" onClick={() => setShowCart(false)} />
          <div className="relative w-full max-w-md h-full bg-white dark:bg-slate-900 shadow-2xl p-8 flex flex-col animate-in slide-in-from-right duration-300">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-2xl font-black text-slate-900 dark:text-white">Shopping Bag</h2>
              <button onClick={() => setShowCart(false)} className="p-3 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors">
                <X className="w-6 h-6 text-slate-400" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-4 pr-2 custom-scrollbar">
              {cart.map((item, idx) => (
                <div key={`${item.id}-${idx}`} className="flex items-center gap-5 p-5 bg-slate-50 dark:bg-slate-800 rounded-[1.5rem] border border-slate-100 dark:border-slate-700 group">
                  <img src={item.imageUrl} className="w-20 h-20 rounded-2xl object-cover shadow-sm" />
                  <div className="flex-1">
                    <h4 className="text-sm font-black text-slate-900 dark:text-white mb-1">{item.name}</h4>
                    <p className="text-lg font-black text-orange-600">{item.price}</p>
                  </div>
                  <button onClick={() => removeFromCart(item.id)} className="p-2 text-slate-300 hover:text-red-500 transition-colors">
                    <X className="w-5 h-5" />
                  </button>
                </div>
              ))}
              {cart.length === 0 && (
                <div className="py-20 text-center">
                  <div className="w-20 h-20 bg-slate-50 dark:bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-6">
                    <ShoppingCart className="w-10 h-10 text-slate-200" />
                  </div>
                  <p className="text-slate-400 font-bold italic">Your shopping bag is empty.</p>
                </div>
              )}
            </div>

            <div className="pt-8 border-t border-slate-100 dark:border-slate-800">
              <div className="flex items-center justify-between mb-8">
                <span className="text-slate-500 font-black uppercase text-xs tracking-widest">Order Subtotal</span>
                <span className="text-3xl font-black text-slate-900 dark:text-white">${totalPrice.toFixed(2)}</span>
              </div>
              <button 
                disabled={cart.length === 0}
                className="w-full py-5 bg-orange-600 text-white rounded-[1.5rem] font-black text-lg shadow-xl shadow-orange-100 disabled:opacity-50 disabled:grayscale transition-all active:scale-95"
              >
                Proceed to Checkout
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Marketplace;
