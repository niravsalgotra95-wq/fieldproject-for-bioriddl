
import React, { useState } from 'react';
import { WellBeingScore, WellBeingActivity, WellBeingMetric, ScoreHistoryPoint } from '../types';
import { Edit2, Plus, Trash2, TrendingUp, TrendingDown, Clock, X, BarChart2, LineChart, ChevronRight, Activity } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

interface ScoreBreakdownProps {
  score: WellBeingScore;
  history: ScoreHistoryPoint[];
  activities: WellBeingActivity[];
  onUpdateScore: (newScore: WellBeingScore) => void;
  onAddActivity: (activity: WellBeingActivity) => void;
  onDeleteActivity: (id: string) => void;
}

const ScoreBreakdown: React.FC<ScoreBreakdownProps> = ({ score, history, activities, onUpdateScore, onAddActivity, onDeleteActivity }) => {
  const [view, setView] = useState<'current' | 'trends'>('current');
  const [range, setRange] = useState<'7D' | '30D'>('7D');
  const [editingMetric, setEditingMetric] = useState<string | null>(null);
  const [isAddingActivity, setIsAddingActivity] = useState(false);
  const [newActivityData, setNewActivityData] = useState<Partial<WellBeingActivity>>({
    category: 'Physical',
    impact: 'Positive',
    description: ''
  });

  const chartData = range === '7D' ? history.slice(-7) : history;

  const handleMetricChange = (label: string, newValue: number) => {
    const updatedMetrics = score.metrics.map(m => 
      m.label === label ? { ...m, value: Math.min(100, Math.max(0, newValue)) } : m
    );
    const overall = Math.round(updatedMetrics.reduce((acc, m) => acc + (m.value * (parseInt(m.weight) / 100)), 0));
    onUpdateScore({ overall, metrics: updatedMetrics });
  };

  const handleSaveActivity = () => {
    if (!newActivityData.description) return;
    const activity: WellBeingActivity = {
      id: Date.now().toString(),
      category: newActivityData.category as any,
      description: newActivityData.description || '',
      impact: newActivityData.impact as any,
      timestamp: 'Just now'
    };
    onAddActivity(activity);
    setIsAddingActivity(false);
    setNewActivityData({ category: 'Physical', impact: 'Positive', description: '' });
  };

  return (
    <div className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] shadow-sm border border-slate-100 dark:border-slate-800 flex flex-col gap-8 transition-colors duration-300">
      <div className="flex items-center justify-between">
        <div>
           <h2 className="text-xl font-black text-slate-900 dark:text-white leading-tight">Well-Being Intel</h2>
           <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest mt-0.5">Progress & Analytics</p>
        </div>
        <div className="flex p-1 bg-slate-50 dark:bg-slate-800 rounded-xl">
          <button 
            onClick={() => setView('current')}
            className={`p-2 rounded-lg transition-all ${view === 'current' ? 'bg-white dark:bg-slate-700 shadow-sm text-orange-600' : 'text-slate-400'}`}
          >
            <BarChart2 className="w-4 h-4" />
          </button>
          <button 
            onClick={() => setView('trends')}
            className={`p-2 rounded-lg transition-all ${view === 'trends' ? 'bg-white dark:bg-slate-700 shadow-sm text-orange-600' : 'text-slate-400'}`}
          >
            <LineChart className="w-4 h-4" />
          </button>
        </div>
      </div>

      {view === 'current' ? (
        <div className="space-y-6 animate-in fade-in duration-500">
          {score.metrics.map((m) => (
            <div key={m.label} className="group relative">
              <div className="flex justify-between items-center mb-2.5 text-xs font-black uppercase tracking-widest text-slate-400 dark:text-slate-500">
                <div className="flex items-center gap-2">
                  <span>{m.label} <span className="text-[10px] opacity-60">({m.weight})</span></span>
                  {m.trend !== undefined && m.trend !== 0 && (
                    <span className={`flex items-center text-[10px] ${m.trend > 0 ? 'text-emerald-500' : 'text-red-500'}`}>
                      {m.trend > 0 ? <TrendingUp className="w-2.5 h-2.5 mr-0.5" /> : <TrendingDown className="w-2.5 h-2.5 mr-0.5" />}
                      {Math.abs(m.trend)}%
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  {editingMetric === m.label ? (
                    <input 
                      type="number" 
                      className="w-12 text-right font-black text-orange-600 dark:text-orange-400 border-b-2 border-orange-300 dark:border-orange-800 focus:outline-none bg-transparent"
                      value={m.value}
                      onChange={(e) => handleMetricChange(m.label, parseInt(e.target.value) || 0)}
                      onBlur={() => setEditingMetric(null)}
                      autoFocus
                    />
                  ) : (
                    <span 
                      className="font-black text-slate-900 dark:text-white cursor-pointer hover:text-orange-600 dark:hover:text-orange-400 transition-colors"
                      onClick={() => setEditingMetric(m.label)}
                    >
                      {m.value}%
                    </span>
                  )}
                  <Edit2 className="w-3 h-3 text-slate-300 group-hover:text-orange-400 transition-colors" />
                </div>
              </div>
              <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-3 overflow-hidden">
                <div 
                  className={`h-full rounded-full transition-all duration-1000 ease-out bg-orange-500 shadow-[0_0_10px_rgba(249,115,22,0.4)]`} 
                  style={{ width: `${m.value}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="space-y-6 animate-in fade-in slide-in-from-right duration-500">
          <div className="flex justify-center gap-2">
            <button 
              onClick={() => setRange('7D')}
              className={`px-4 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${range === '7D' ? 'bg-orange-600 text-white' : 'bg-slate-50 dark:bg-slate-800 text-slate-400'}`}
            >
              7 Days
            </button>
            <button 
              onClick={() => setRange('30D')}
              className={`px-4 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${range === '30D' ? 'bg-orange-600 text-white' : 'bg-slate-50 dark:bg-slate-800 text-slate-400'}`}
            >
              30 Days
            </button>
          </div>

          <div className="h-[250px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorPhysical" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorEmotional" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ec4899" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#ec4899" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="date" stroke="#94a3b8" fontSize={10} axisLine={false} tickLine={false} interval={range === '30D' ? 5 : 0} />
                <YAxis hide domain={[0, 100]} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#fff', 
                    borderRadius: '16px', 
                    border: 'none', 
                    boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)',
                    fontSize: '11px',
                    fontWeight: 'bold'
                  }}
                  itemStyle={{ padding: '2px 0' }}
                />
                <Legend 
                  verticalAlign="top" 
                  iconType="circle" 
                  wrapperStyle={{ fontSize: '9px', fontWeight: '900', textTransform: 'uppercase', letterSpacing: '0.05em', paddingBottom: '20px' }} 
                />
                <Area type="monotone" dataKey="Physical" stroke="#3b82f6" fill="url(#colorPhysical)" strokeWidth={3} dot={range === '7D'} activeDot={{ r: 6 }} />
                <Area type="monotone" dataKey="Emotional" stroke="#ec4899" fill="url(#colorEmotional)" strokeWidth={3} dot={range === '7D'} activeDot={{ r: 6 }} />
                <Area type="monotone" dataKey="Behavioral" stroke="#a855f7" fill="none" strokeWidth={3} strokeDasharray="5 5" />
                <Area type="monotone" dataKey="Routine" stroke="#10b981" fill="none" strokeWidth={3} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          
          <div className="p-4 bg-orange-50 dark:bg-orange-900/10 rounded-2xl border border-orange-100 dark:border-orange-900/30">
            <div className="flex items-center gap-2 mb-1.5">
              <Activity className="w-4 h-4 text-orange-600" />
              <span className="text-[10px] font-black text-orange-700 dark:text-orange-400 uppercase tracking-widest">
                {range} Analysis Summary
              </span>
            </div>
            <p className="text-[11px] font-bold text-slate-600 dark:text-slate-300 leading-relaxed">
              {range === '7D' 
                ? "Your live entries are currently pushing the score upwards. Maintain this trend to reach a new wellness peak!" 
                : "A 30-day baseline shows high routine stability despite session-based variations. Great consistency!"
              }
            </p>
          </div>
        </div>
      )}

      <div className="pt-8 border-t border-slate-50 dark:border-slate-800">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-sm font-black uppercase tracking-widest text-slate-900 dark:text-white">Recent Activities</h3>
          <button 
            onClick={() => setIsAddingActivity(true)}
            className="p-2.5 bg-orange-600 text-white rounded-xl hover:bg-orange-700 transition-all shadow-lg shadow-orange-100 dark:shadow-none active:scale-95"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>

        {isAddingActivity && (
          <div className="mb-6 p-5 bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700 rounded-2xl animate-in slide-in-from-top-4 duration-300">
            <div className="flex justify-between items-center mb-4">
              <span className="text-[10px] font-black uppercase text-slate-400 dark:text-slate-500 tracking-widest">New Event Log</span>
              <button onClick={() => setIsAddingActivity(false)} className="p-1 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors"><X className="w-4 h-4 text-slate-400" /></button>
            </div>
            <input 
              type="text" 
              placeholder="What happened? (e.g. Extra long play)"
              className="w-full text-sm p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl mb-3 focus:ring-4 focus:ring-orange-50 dark:focus:ring-orange-900/10 outline-none dark:text-white transition-all"
              value={newActivityData.description}
              onChange={e => setNewActivityData({...newActivityData, description: e.target.value})}
            />
            <div className="grid grid-cols-2 gap-3 mb-4">
              <select 
                className="w-full text-xs p-3 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 dark:text-white outline-none"
                value={newActivityData.category}
                onChange={e => setNewActivityData({...newActivityData, category: e.target.value as any})}
              >
                <option value="Physical">Physical</option>
                <option value="Emotional">Emotional</option>
                <option value="Behavioral">Behavioral</option>
                <option value="Routine">Routine</option>
              </select>
              <select 
                className="w-full text-xs p-3 border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-900 dark:text-white outline-none"
                value={newActivityData.impact}
                onChange={e => setNewActivityData({...newActivityData, impact: e.target.value as any})}
              >
                <option value="Positive">Positive (+5)</option>
                <option value="Negative">Negative (-10)</option>
                <option value="Neutral">Neutral</option>
              </select>
            </div>
            <button 
              onClick={handleSaveActivity}
              className="w-full py-4 bg-orange-600 text-white rounded-xl font-black text-xs uppercase tracking-widest hover:bg-orange-700 transition-all shadow-xl shadow-orange-100 dark:shadow-none"
            >
              Post Activity
            </button>
          </div>
        )}

        <div className="space-y-4 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
          {activities.map(act => (
            <div key={act.id} className="group flex items-start gap-4 p-4 rounded-2xl hover:bg-orange-50 dark:hover:bg-slate-800 transition-all border border-transparent hover:border-orange-100 dark:hover:border-slate-700">
              <div className={`mt-1 p-2 rounded-xl ${
                act.impact === 'Positive' ? 'bg-emerald-100 text-emerald-600 dark:bg-emerald-900/30' : 
                act.impact === 'Negative' ? 'bg-red-100 text-red-600 dark:bg-red-900/30' : 'bg-slate-100 text-slate-500 dark:bg-slate-800'
              }`}>
                {act.impact === 'Positive' ? <TrendingUp className="w-4 h-4" /> : 
                 act.impact === 'Negative' ? <TrendingDown className="w-4 h-4" /> : <Clock className="w-4 h-4" />}
              </div>
              <div className="flex-1">
                <p className="text-sm font-bold text-slate-800 dark:text-white leading-tight mb-1.5">{act.description}</p>
                <div className="flex items-center gap-3">
                  <span className="text-[10px] font-black text-orange-600 dark:text-orange-400 uppercase tracking-widest">{act.category}</span>
                  <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 italic">{act.timestamp}</span>
                </div>
              </div>
              <button 
                onClick={() => onDeleteActivity(act.id)}
                className="opacity-0 group-hover:opacity-100 p-1.5 text-slate-300 hover:text-red-500 transition-all"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ScoreBreakdown;
