
import React, { useState } from 'react';
import { PetProfile } from '../types';
import { User, Plus, Trash2, Tag, Info, X } from 'lucide-react';

interface PetProfileCardProps {
  pet: PetProfile;
  onAddAttribute: (key: string, value: string) => void;
  onDeleteAttribute: (id: string) => void;
}

const PetProfileCard: React.FC<PetProfileCardProps> = ({ pet, onAddAttribute, onDeleteAttribute }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [newKey, setNewKey] = useState('');
  const [newVal, setNewVal] = useState('');

  const handleAdd = () => {
    if (newKey.trim() && newVal.trim()) {
      onAddAttribute(newKey.trim(), newVal.trim());
      setNewKey('');
      setNewVal('');
      setIsAdding(false);
    }
  };

  return (
    <div className="bg-white dark:bg-slate-900 p-6 rounded-[2rem] shadow-sm border border-slate-100 dark:border-slate-800 transition-colors duration-300">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-orange-50 dark:bg-orange-900/20 rounded-2xl">
            <User className="w-5 h-5 text-orange-600 dark:text-orange-400" />
          </div>
          <div>
            <h2 className="text-base font-black text-slate-900 dark:text-white uppercase tracking-tight">Pet Profile</h2>
            <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest leading-none">Identity & Details</p>
          </div>
        </div>
        <button 
          onClick={() => setIsAdding(!isAdding)}
          className={`p-2 rounded-xl transition-all ${isAdding ? 'bg-orange-600 text-white' : 'bg-slate-50 dark:bg-slate-800 text-slate-400 hover:text-orange-600'}`}
        >
          {isAdding ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
        </button>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-6">
        <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-100 dark:border-slate-800">
          <p className="text-[9px] font-black text-slate-400 dark:text-slate-500 uppercase mb-0.5 tracking-wider">Breed</p>
          <p className="text-xs font-bold text-slate-800 dark:text-white truncate">{pet.breed}</p>
        </div>
        <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-100 dark:border-slate-800">
          <p className="text-[9px] font-black text-slate-400 dark:text-slate-500 uppercase mb-0.5 tracking-wider">Category</p>
          <p className="text-xs font-bold text-slate-800 dark:text-white">{pet.category}</p>
        </div>
      </div>

      <div className="space-y-2.5">
        {pet.customAttributes.map((attr) => (
          <div key={attr.id} className="group flex items-center justify-between p-3 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl hover:border-orange-100 dark:hover:border-orange-900/30 transition-all shadow-sm">
            <div className="flex items-center gap-3">
              <div className="p-1.5 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                <Tag className="w-3 h-3 text-orange-600 dark:text-orange-400" />
              </div>
              <div className="overflow-hidden">
                <p className="text-[8px] font-black text-slate-400 dark:text-slate-500 uppercase leading-none mb-1 tracking-widest">{attr.key}</p>
                <p className="text-xs font-bold text-slate-800 dark:text-white truncate">{attr.value}</p>
              </div>
            </div>
            <button 
              onClick={() => onDeleteAttribute(attr.id)}
              className="opacity-0 group-hover:opacity-100 p-1.5 text-slate-300 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-all"
            >
              <Trash2 className="w-3 h-3" />
            </button>
          </div>
        ))}

        {isAdding && (
          <div className="p-4 bg-orange-50 dark:bg-orange-900/10 rounded-2xl border border-orange-100 dark:border-orange-900/30 animate-in fade-in slide-in-from-top-2">
            <div className="space-y-3">
              <div className="space-y-1">
                <label className="text-[9px] font-black text-orange-700 dark:text-orange-400 uppercase tracking-widest px-1">Attribute Name</label>
                <input 
                  className="w-full p-3 text-xs bg-white dark:bg-slate-900 border border-orange-100 dark:border-slate-800 rounded-xl outline-none focus:ring-4 focus:ring-orange-100 dark:focus:ring-orange-900/20 dark:text-white transition-all"
                  placeholder="e.g. Microchip ID"
                  value={newKey}
                  onChange={e => setNewKey(e.target.value)}
                />
              </div>
              <div className="space-y-1">
                <label className="text-[9px] font-black text-orange-700 dark:text-orange-400 uppercase tracking-widest px-1">Value</label>
                <input 
                  className="w-full p-3 text-xs bg-white dark:bg-slate-900 border border-orange-100 dark:border-slate-800 rounded-xl outline-none focus:ring-4 focus:ring-orange-100 dark:focus:ring-orange-900/20 dark:text-white transition-all"
                  placeholder="e.g. 985-112-..."
                  value={newVal}
                  onChange={e => setNewVal(e.target.value)}
                />
              </div>
              <button 
                onClick={handleAdd}
                className="w-full py-3 bg-orange-600 text-white text-[10px] font-black uppercase tracking-widest rounded-xl hover:bg-orange-700 transition-all shadow-lg shadow-orange-100 dark:shadow-none"
              >
                Add Attribute
              </button>
            </div>
          </div>
        )}

        {pet.customAttributes.length === 0 && !isAdding && (
          <div className="p-8 text-center border-2 border-dashed border-slate-100 dark:border-slate-800 rounded-3xl">
            <Info className="w-6 h-6 text-slate-300 dark:text-slate-700 mx-auto mb-3" />
            <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 italic leading-relaxed">
              No custom details found.<br/>Click + to add tags like "Favorite Toy".
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default PetProfileCard;
