
import React from 'react';
import { User, Bell, Shield, Key, Moon, Sun, Globe, CreditCard } from 'lucide-react';

interface SettingsHubProps {
  darkMode: boolean;
  onToggleDarkMode: () => void;
}

const SettingsHub: React.FC<SettingsHubProps> = ({ darkMode, onToggleDarkMode }) => {
  const openApiKeySelector = async () => {
    try {
      if (window.aistudio && typeof window.aistudio.openSelectKey === 'function') {
        await window.aistudio.openSelectKey();
        alert("API Key updated for advanced features. Please note: Veo and Gemini 3 Pro require a paid project key.");
      } else {
        alert("API Key selector is only available in the AI Studio environment.");
      }
    } catch (err) {
      console.error("Failed to open key selector:", err);
    }
  };

  const sections = [
    { title: 'Personal Account', icon: User, desc: 'Manage your profile and linked accounts' },
    { title: 'Notifications', icon: Bell, desc: 'Alert preferences for health and safety' },
    { title: 'Privacy & Security', icon: Shield, desc: 'Control your data sharing and login methods' },
    { title: 'Billing & Plans', icon: CreditCard, desc: 'Insurance premiums and shop subscriptions' }
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-500 pb-20">
      <div className="bg-white dark:bg-slate-900 p-6 md:p-10 rounded-[3rem] shadow-sm border border-slate-100 dark:border-slate-800">
        <h2 className="text-3xl font-black text-slate-900 dark:text-white mb-10">Application Settings</h2>
        
        <div className="space-y-8">
          {/* Advanced AI Section */}
          <div className="p-6 md:p-8 bg-indigo-50 dark:bg-indigo-950/20 rounded-[2.5rem] border border-indigo-100 dark:border-indigo-900/30">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="flex items-start gap-4">
                <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl shadow-sm text-indigo-600">
                  <Key className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="text-xl font-black text-slate-900 dark:text-white">Advanced AI Features</h3>
                  <p className="text-sm text-slate-500 font-medium max-w-sm mt-1">Unlock Gemini 3 Pro Thinking and Veo 3 Video generation by selecting a paid API key.</p>
                  <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" className="text-[10px] font-black uppercase text-indigo-600 mt-2 block hover:underline tracking-widest">Learn about billing</a>
                </div>
              </div>
              <button 
                onClick={openApiKeySelector}
                className="px-8 py-4 bg-indigo-600 text-white rounded-2xl font-black text-sm uppercase tracking-widest shadow-lg shadow-indigo-100 dark:shadow-none hover:scale-105 transition-all"
              >
                Configure Keys
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {sections.map((sec) => (
              <div key={sec.title} className="p-6 bg-slate-50 dark:bg-slate-800 rounded-[2rem] border border-slate-100 dark:border-slate-700 hover:border-orange-200 transition-all group cursor-pointer">
                <div className="flex items-center gap-4 mb-4">
                  <div className="p-3 bg-white dark:bg-slate-900 rounded-xl shadow-sm text-slate-400 group-hover:text-orange-600">
                    <sec.icon className="w-6 h-6" />
                  </div>
                  <h4 className="font-black text-slate-900 dark:text-white">{sec.title}</h4>
                </div>
                <p className="text-sm text-slate-500 font-medium">{sec.desc}</p>
              </div>
            ))}
          </div>

          <div className="pt-8 border-t border-slate-100 dark:border-slate-800">
            <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-6 px-4">Display & Preferences</h4>
            <div className="space-y-4">
              <button 
                onClick={onToggleDarkMode}
                className="w-full flex items-center justify-between p-6 bg-slate-50 dark:bg-slate-800 rounded-3xl group"
              >
                <div className="flex items-center gap-4">
                  {darkMode ? <Sun className="w-6 h-6 text-amber-500" /> : <Moon className="w-6 h-6 text-slate-400" />}
                  <span className="font-black text-slate-900 dark:text-white">{darkMode ? 'Light Mode' : 'Dark Mode'}</span>
                </div>
                <div className={`w-14 h-7 rounded-full p-1 transition-colors ${darkMode ? 'bg-orange-600' : 'bg-slate-300'}`}>
                  <div className={`w-5 h-5 bg-white rounded-full transition-transform ${darkMode ? 'translate-x-7' : 'translate-x-0 shadow-sm'}`} />
                </div>
              </button>

              <div className="w-full flex items-center justify-between p-6 bg-slate-50 dark:bg-slate-800 rounded-3xl">
                <div className="flex items-center gap-4">
                  <Globe className="w-6 h-6 text-slate-400" />
                  <span className="font-black text-slate-900 dark:text-white">Language</span>
                </div>
                <span className="text-sm font-black text-orange-600 bg-orange-50 dark:bg-orange-950/40 px-4 py-2 rounded-xl">English (US)</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SettingsHub;
