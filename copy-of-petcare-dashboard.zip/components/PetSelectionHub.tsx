
import React from 'react';
import { PetProfile, PetCategory } from '../types';
import { 
  Dog, Cat, Bird, Fish, HelpCircle, Heart, Plus, 
  ChevronRight, Moon, Sun, LogOut, Search, Turtle
} from 'lucide-react';

interface PetSelectionHubProps {
  pets: PetProfile[];
  onSelect: (pet: PetProfile) => void;
  onAdd: (category: PetCategory) => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
}

const PetSelectionHub: React.FC<PetSelectionHubProps> = ({ 
  pets, onSelect, onAdd, darkMode, onToggleDarkMode 
}) => {
  const categories: { name: PetCategory; icon: any }[] = [
    { name: 'Dog', icon: Dog },
    { name: 'Cat', icon: Cat },
    { name: 'Bird', icon: Bird },
    { name: 'Fish', icon: Fish },
    { name: 'Reptile', icon: Turtle },
    { name: 'Small Mammal', icon: Heart }
  ];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 p-6 md:p-12 transition-colors duration-500">
      <div className="max-w-6xl mx-auto">
        {/* Header Section */}
        <header className="flex flex-col md:flex-row justify-between items-start md:items-center mb-12 gap-6">
          <div className="animate-in fade-in slide-in-from-left duration-700">
            <h1 className="text-4xl md:text-5xl font-black text-slate-900 dark:text-white mb-3">
              Pet <span className="text-orange-600">Portal</span>
            </h1>
            <p className="text-slate-500 dark:text-slate-400 font-bold text-lg">
              Manage your pet family in one unified space.
            </p>
          </div>
          
          <div className="flex items-center gap-4 animate-in fade-in slide-in-from-right duration-700">
            <button 
              onClick={onToggleDarkMode} 
              className="p-4 bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800 text-slate-500 hover:text-orange-600 transition-all hover:scale-105"
            >
              {darkMode ? <Sun className="w-6 h-6" /> : <Moon className="w-6 h-6" />}
            </button>
            <div className="w-12 h-12 bg-orange-600 rounded-2xl flex items-center justify-center shadow-lg shadow-orange-100 dark:shadow-none">
              <Plus className="w-6 h-6 text-white" />
            </div>
          </div>
        </header>

        {/* Search Bar - Aesthetic Only for Hub */}
        <div className="mb-12 relative group max-w-xl animate-in fade-in slide-in-from-bottom-4 duration-700 delay-100">
          <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 group-focus-within:text-orange-600 transition-colors" />
          <input 
            type="text" 
            placeholder="Search your pets..." 
            className="w-full pl-14 pr-6 py-5 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl text-sm focus:outline-none focus:ring-4 focus:ring-orange-50 dark:focus:ring-orange-900/10 focus:border-orange-200 transition-all shadow-sm font-medium dark:text-white"
          />
        </div>

        {/* Existing Pets Section */}
        <section className="mb-20">
          <div className="flex items-center justify-between mb-8 px-2">
            <h2 className="text-xl font-black text-slate-900 dark:text-white uppercase tracking-widest">Active Members</h2>
            <span className="text-xs font-black text-orange-600 bg-orange-50 dark:bg-orange-900/20 px-3 py-1.5 rounded-xl border border-orange-100 dark:border-orange-900/30">
              {pets.length} Household {pets.length === 1 ? 'Pet' : 'Pets'}
            </span>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {pets.map((p, idx) => (
              <div 
                key={p.id} 
                onClick={() => onSelect(p)}
                style={{ animationDelay: `${idx * 100}ms` }}
                className="group bg-white dark:bg-slate-900 p-7 rounded-[3rem] shadow-xl hover:shadow-2xl hover:scale-[1.02] cursor-pointer transition-all border border-transparent hover:border-orange-200 dark:hover:border-orange-900/40 relative overflow-hidden animate-in fade-in slide-in-from-bottom-6 duration-700"
              >
                <div className="flex items-center gap-6 relative z-10">
                  <div className="relative">
                    <img 
                      src={p.imageUrl} 
                      className="w-24 h-24 rounded-[2rem] object-cover ring-8 ring-orange-50 dark:ring-slate-800 transition-all group-hover:ring-orange-100 dark:group-hover:ring-orange-900/30" 
                      alt={p.name}
                    />
                    <div className="absolute -bottom-2 -right-2 bg-orange-600 p-2 rounded-xl text-white shadow-lg">
                      <ChevronRight className="w-4 h-4" />
                    </div>
                  </div>
                  <div>
                    <h3 className="text-2xl font-black text-slate-900 dark:text-white mb-1 group-hover:text-orange-600 transition-colors">{p.name}</h3>
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-[10px] font-black text-white bg-slate-900 dark:bg-slate-800 px-2 py-1 rounded-lg uppercase tracking-wider">
                        {p.category}
                      </span>
                      <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase">
                        {p.breed}
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5 text-xs text-orange-600 font-black uppercase tracking-tight">
                      Open Dashboard <ChevronRight className="w-3.5 h-3.5" />
                    </div>
                  </div>
                </div>
                {/* Background Decoration */}
                <div className="absolute -top-12 -right-12 w-32 h-32 bg-orange-50 dark:bg-orange-950/20 rounded-full blur-3xl opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            ))}
          </div>
        </section>

        {/* Add New Pet Section */}
        <section className="pt-12 border-t border-slate-200 dark:border-slate-800">
          <div className="flex flex-col items-center text-center mb-12">
            <h2 className="text-2xl font-black text-slate-900 dark:text-white mb-2">Grow Your Family</h2>
            <p className="text-slate-500 dark:text-slate-400 font-bold">Select a category to begin personalized onboarding</p>
          </div>
          
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-6">
            {categories.map((cat, idx) => (
              <button 
                key={cat.name}
                onClick={() => onAdd(cat.name)}
                style={{ animationDelay: `${500 + (idx * 100)}ms` }}
                className="flex flex-col items-center gap-5 p-8 bg-white dark:bg-slate-900 rounded-[2.5rem] border border-slate-100 dark:border-slate-800 hover:border-orange-500 hover:bg-orange-50 dark:hover:bg-orange-950/20 transition-all group shadow-sm hover:shadow-xl hover:-translate-y-2 animate-in fade-in zoom-in duration-500"
              >
                <div className="w-16 h-16 flex items-center justify-center bg-slate-50 dark:bg-slate-800 rounded-[1.5rem] group-hover:bg-white dark:group-hover:bg-slate-700 transition-all group-hover:rotate-12 group-hover:scale-110 shadow-sm">
                  <cat.icon className="w-8 h-8 text-slate-400 dark:text-slate-600 group-hover:text-orange-600 transition-colors" />
                </div>
                <span className="text-[10px] font-black text-slate-600 dark:text-slate-400 uppercase tracking-[0.2em]">
                  {cat.name}
                </span>
              </button>
            ))}
          </div>
        </section>

        {/* Global Footer Controls */}
        <footer className="mt-20 flex justify-center pb-12">
          <button 
            onClick={() => window.location.reload()}
            className="flex items-center gap-3 px-8 py-4 text-slate-400 hover:text-orange-600 transition-all font-black text-sm uppercase tracking-widest"
          >
            <LogOut className="w-5 h-5" /> Sign Out
          </button>
        </footer>
      </div>
    </div>
  );
};

export default PetSelectionHub;
