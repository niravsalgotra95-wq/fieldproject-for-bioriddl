
import React, { useState } from 'react';
import { PetProfile, WellBeingScore, EmotionalState } from '../types';
import { ShieldCheck, Heart, AlertTriangle, ChevronDown } from 'lucide-react';

interface SummaryBarProps {
  pet: PetProfile;
  score: WellBeingScore;
  emotionalState: EmotionalState;
  onEmotionChange: (newEmotion: EmotionalState) => void;
  alertCount: number;
}

const SummaryBar: React.FC<SummaryBarProps> = ({ pet, score, emotionalState, onEmotionChange, alertCount }) => {
  const [showMoodMenu, setShowMoodMenu] = useState(false);

  const getScoreColor = (val: number) => {
    if (val >= 80) return 'text-emerald-600 bg-emerald-50 dark:bg-emerald-900/20 border-emerald-200 dark:border-emerald-800';
    if (val >= 50) return 'text-amber-600 bg-amber-50 dark:bg-amber-900/20 border-amber-200 dark:border-amber-800';
    return 'text-red-600 bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800';
  };

  const emotionEmoji: Record<EmotionalState, string> = {
    Calm: '😌',
    Happy: '😊',
    Bored: '😐',
    Stressed: '😟',
    Anxious: '😰',
    Aggressive: '😠'
  };

  const moods: EmotionalState[] = ['Calm', 'Happy', 'Bored', 'Stressed', 'Anxious', 'Aggressive'];

  return (
    <div className="flex flex-col md:flex-row items-center justify-between p-6 bg-white dark:bg-slate-900 rounded-[2rem] shadow-sm border border-slate-100 dark:border-slate-800 gap-6 mb-8 transition-colors duration-300">
      <div className="flex items-center gap-6">
        <div className="relative">
           <img 
            src={pet.imageUrl} 
            alt={pet.name} 
            className="w-20 h-20 rounded-[1.5rem] object-cover ring-4 ring-orange-50 dark:ring-slate-800 shadow-lg"
          />
          <div className="absolute -bottom-2 -right-2 bg-white dark:bg-slate-900 p-1.5 rounded-xl shadow-md border border-slate-100 dark:border-slate-800">
            <Heart className="w-4 h-4 text-orange-600 fill-current" />
          </div>
        </div>
        <div>
          <h1 className="text-2xl font-black text-slate-900 dark:text-white mb-0.5">{pet.name}</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider">{pet.breed} • {pet.age} Years</p>
        </div>
      </div>

      <div className="flex flex-wrap items-center justify-center gap-4">
        <div className={`flex items-center gap-3 px-5 py-3 rounded-2xl border transition-all ${getScoreColor(score.overall)}`}>
          <ShieldCheck className="w-6 h-6" />
          <div className="flex flex-col">
            <span className="font-black text-lg leading-none">{score.overall}</span>
            <span className="text-[10px] font-black uppercase tracking-tighter opacity-80">Score</span>
          </div>
        </div>

        <div className="relative">
          <button 
            onClick={() => setShowMoodMenu(!showMoodMenu)}
            className="flex items-center gap-3 px-5 py-3 bg-orange-50 dark:bg-orange-900/10 border border-orange-100 dark:border-orange-900/30 text-orange-700 dark:text-orange-400 rounded-2xl hover:bg-orange-100 dark:hover:bg-orange-900/20 transition-all font-black text-sm"
          >
            <span className="text-xl">{emotionEmoji[emotionalState]}</span>
            <span>{emotionalState}</span>
            <ChevronDown className={`w-4 h-4 transition-transform duration-300 ${showMoodMenu ? 'rotate-180' : ''}`} />
          </button>
          
          {showMoodMenu && (
            <div className="absolute top-full mt-3 right-0 w-56 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl shadow-2xl p-3 z-[100] animate-in fade-in slide-in-from-top-2">
              <p className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase px-4 py-2 mb-2 tracking-widest border-b border-slate-50 dark:border-slate-800">Mood Selector</p>
              <div className="grid grid-cols-1 gap-1">
                {moods.map(mood => (
                  <button
                    key={mood}
                    onClick={() => {
                      onEmotionChange(mood);
                      setShowMoodMenu(false);
                    }}
                    className={`flex items-center gap-4 px-4 py-3 rounded-xl text-sm transition-all ${
                      emotionalState === mood 
                        ? 'bg-orange-600 text-white font-black shadow-lg shadow-orange-100 dark:shadow-none' 
                        : 'text-slate-600 dark:text-slate-400 hover:bg-orange-50 dark:hover:bg-slate-800'
                    }`}
                  >
                    <span className="text-lg">{emotionEmoji[mood]}</span> {mood}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {alertCount > 0 && (
          <div className="flex items-center gap-3 px-5 py-3 bg-red-50 dark:bg-red-900/10 border border-red-100 dark:border-red-900/30 text-red-600 dark:text-red-400 rounded-2xl animate-pulse font-black text-sm uppercase tracking-wider">
            <AlertTriangle className="w-5 h-5" />
            <span>{alertCount} Risk Alerts</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default SummaryBar;
